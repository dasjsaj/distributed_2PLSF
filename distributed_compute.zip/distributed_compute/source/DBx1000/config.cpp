#include "config.h"

TPCCTxnType 			g_tpcc_txn_type = TPCC_ALL;
TestCases				g_test_case = CONFLICT;

